/*
 * help.h: header for help.c
 *
 * copyright(c) 1994 matthew green
 *
 * See the copyright file, or do a help ircii copyright 
 *
 * @(#)$Id: help.h 3 2008-02-25 09:49:14Z keaston $
 */

#ifndef __help_h
# define __help_h

	void	help (char *, char *, char *, char *);

#endif /* __help_h */
